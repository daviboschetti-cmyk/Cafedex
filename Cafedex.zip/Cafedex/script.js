document.addEventListener("DOMContentLoaded", () => {
    let indexAtual = 0;

    const container = document.getElementById("produtos");
    const btnAvancar = document.querySelector(".seta_direita");
    const btnVoltar = document.querySelector(".seta_esquerda");

    function atualizarPosicao() {
        const passo = 370;
        container.style.transform = `translateX(-${indexAtual * passo}px)`;
    }

    if (btnAvancar) {
        btnAvancar.addEventListener("click", () => {
            const cards = container.querySelectorAll(".card");
            const maxIndex = cards.length - 3; 

            if (indexAtual < maxIndex) {
                indexAtual++;
            } else {
                indexAtual = 0; 
            }
            atualizarPosicao();
        });
    }

    if (btnVoltar) {
        btnVoltar.addEventListener("click", () => {
            const cards = container.querySelectorAll(".card");
            const maxIndex = cards.length - 3;

            if (indexAtual > 0) {
                indexAtual--;
            } else {
                indexAtual = maxIndex; 
            }
            atualizarPosicao();
        });
    }
});